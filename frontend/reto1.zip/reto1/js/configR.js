window.addEventListener('load',()=>{
    boton = document.querySelector("#boton");
    boton.addEventListener('click',async ()=>{
        let newUser = {
            nombre: document.querySelector("#nombre").value,
            email: document.querySelector("#email").value,
            password: document.querySelector("#pwd").value,
            password_conf: document.querySelector("#pwd-confirm").value,
            terminos: document.querySelector("#terminos").checked
        }
        if(validarRegistro(newUser)){
            let registrar = {
                name: newUser.nombre,
                email: newUser.email,
                password: newUser.password
            }
            await registrarUsuario(registrar);
        }else{
            console.log("error");
        }
    });
});

async function registrarUsuario(registrar){
    try {
        console.log(registrar);
        test()
        return
        var myHeaders = new Headers();
        myHeaders.append("Connection", "keep-alive");
        myHeaders.append("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36");
        myHeaders.append("Content-Type", "application/json");
        myHeaders.append("Accept", "*/*");
        myHeaders.append("Origin", "http://127.0.0.1:5501");
        myHeaders.append("Referer", "http://127.0.0.1:5501/");
        myHeaders.append("Accept-Language", "es-419,es;q=0.9");
        alert(JSON.stringify(registrar));
        response = await fetch("http://144.22.58.188:8080/api/user/new",{
            method: 'POST',
            mode: 'no-cors',
            headers : myHeaders,
            body: JSON.stringify(registrar)
        });
        responsejson = await response.json();
        console.log(responsejson);
        document.location("login.html")
        alert("registro satisfactorio");
    } catch (error) {
        console.log(error);
        alert("Ha ocurrido un error en el servidor :(")
    }
}

function test(){
    var myHeaders = new Headers();
    myHeaders.append("Connection", "keep-alive");
    myHeaders.append("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.45 Safari/537.36");
    myHeaders.append("Content-Type", "application/json");
    myHeaders.append("Accept", "*/*");
    myHeaders.append("Origin", "http://127.0.0.1:5501");
    myHeaders.append("Referer", "http://127.0.0.1:5501/");
    myHeaders.append("Accept-Language", "es-419,es;q=0.9");

    var raw = JSON.stringify({
    "name": "andres",
    "email": "est.andresc.gutier1@unimilitar.edu.co",
    "password": "1234567"
    });

    var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
    redirect: 'follow'
    };

    fetch("http://144.22.58.188:8080/api/user/new", requestOptions)
    .then(response => response.text())
    .then(result => console.log(result))
    .catch(error => console.log('error', error));
}





















