const url = "192.168.0.18:8080"

/* Roles */
const ADMIN = "ADM"
const COORINADOR = "COORD"
const ASSESOR = "ASE"