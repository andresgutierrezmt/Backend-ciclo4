function errorAlert(text, mensaje){

}